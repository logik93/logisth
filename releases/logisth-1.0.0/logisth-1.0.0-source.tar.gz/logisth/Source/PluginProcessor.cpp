#include "PluginProcessor.h"
#include "FactoryPresets.h"
#include "PluginEditor.h"
using namespace juce;
using namespace logisth;
AudioProcessorValueTreeState::ParameterLayout LogisthProcessor::layout() {
    AudioProcessorValueTreeState::ParameterLayout layout;
    for (const auto &s : parameterSpecs) {
        String name = String(s.group) + " / " + s.label;
        if (*s.choices) {
            auto choices = StringArray::fromTokens(s.choices, "|", "");
            layout.add(std::make_unique<AudioParameterChoice>(ParameterID{s.id, 1}, name, choices,
                                                              int(s.initial)));
        } else if (s.integer)
            layout.add(std::make_unique<AudioParameterInt>(ParameterID{s.id, 1}, name, int(s.low),
                                                           int(s.high), int(s.initial)));
        else
            layout.add(std::make_unique<AudioParameterFloat>(
                ParameterID{s.id, 1}, name, NormalisableRange<float>(s.low, s.high, 0, s.skew),
                s.initial,
                AudioParameterFloatAttributes().withStringFromValueFunction([](float v, int) {
                    return String(v, std::abs(v) >= 100                   ? 0
                                     : std::abs(v) > 0 && std::abs(v) < 1 ? 3
                                                                          : 2);
                })));
    }
    return layout;
}
LogisthProcessor::LogisthProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", AudioChannelSet::stereo(), true)),
      state(*this, nullptr, "LogisthState", layout()) {
    for (size_t i = 0; i < parameterCount; ++i)
        raw[i] = state.getRawParameterValue(parameterSpecs[i].id);
    for (int i = 0; i < playerCount; ++i)
        publishSource(i, SourceData::factory());
    auto map = std::make_shared<ChordMap>();
    for (int i = 0; i < 128; ++i)
        map->set(i, 1);
    publishChords(map);
    loadPreset(0);
    preparation.startThread();
}
Params LogisthProcessor::snapshot() const {
    Params p;
    p.fixedVelocity = get(Param::fixedvelocity) > 0;
    p.spectralBank = spectralPointer.load();
    for (int i = 0; i < playerCount; ++i) {
        size_t at = playerParamIndex(Param::o1wave, i, 12);
        auto next = [&] { return get(Param(at++)); };
        auto &o = p.osc[size_t(i)];
        o.wave = int(next());
        o.unison = int(next());
        o.level = next();
        float octave = next();
        float note = next();
        float fine = next();
        o.semitone = octave * 12 + note + fine * .01f;
        o.phase = next();
        o.detune = next() + get(detuneExtra(i)) + get(detuneWide(i));
        o.blend = get(unisonBlend(i));
        o.stereo = next();
        o.pan = next();
        o.retrigger = next() > 0;
        o.invert = next() > 0;
        size_t ext = playerParamIndex(Param::o1engine, i, 16);
        auto sourceNext = [&] { return get(Param(ext++)); };
        o.engine = int(sourceNext());
        o.position = sourceNext();
        o.end = sourceNext();
        o.root = int(sourceNext());
        o.loop = sourceNext() > 0;
        o.reverse = sourceNext() > 0;
        o.size = sourceNext() * .001f;
        o.density = sourceNext();
        o.spray = sourceNext();
        o.scan = sourceNext();
        o.warp = sourceNext();
        o.envelopeEnabled = sourceNext() > 0;
        o.envelope = {sourceNext(), sourceNext(), sourceNext(), sourceNext()};
        size_t modulation = playerParamIndex(Param::o1fmdepth, i, 10);
        o.fmDepth = get(Param(modulation));
        o.fmRatio = get(Param(modulation + 1));
        o.amDepth = get(Param(modulation + 2));
        o.amRatio = get(Param(modulation + 3));
        o.pulseWidth = get(Param(modulation + 4));
        o.pwmDepth = get(Param(modulation + 5));
        o.pwmRate = get(Param(modulation + 6));
        o.stretchMode = int(get(Param(modulation + 7)));
        o.stretch = get(Param(modulation + 8));
        o.interpolation = int(get(Param(modulation + 9)));
        size_t extra = playerParamIndex(Param::o1fmsource, i, 5);
        o.fmSource = int(get(Param(extra)));
        o.amSource = int(get(Param(extra + 1)));
        o.pwmSync = get(Param(extra + 2)) > 0;
        o.pwmDivision = int(get(Param(extra + 3)));
        o.kickAttack = get(Param(extra + 4));
        size_t stretch = playerParamIndex(Param::o1ssrate, i, 6);
        o.stretchControls.rate = get(Param(stretch));
        o.stretchControls.semitones = get(Param(stretch + 1));
        o.stretchControls.tonalityHz = get(Param(stretch + 2));
        o.stretchControls.formant = get(Param(stretch + 3));
        o.stretchControls.blockMs = get(Param(stretch + 4));
        int overlap = int(get(Param(stretch + 5)));
        o.stretchControls.overlap = overlap == 0 ? 0 : overlap + 1;
        const size_t tail = size_t(tailParam(i));
        o.tail.enabled = get(Param(tail)) > 0;
        o.tail.start = get(Param(tail + 1));
        o.tail.end = get(Param(tail + 2));
        o.tail.fadeMs = get(Param(tail + 3));
        o.data = sourcePointers[size_t(i)].load();
        size_t g = playerParamIndex(Param::o1gmodel, i, 15);
        auto granNext = [&] { return get(Param(g++)); };
        o.gran.trimStart = get(Param(playerParamIndex(Param::o1trimstart, i, 1)));
        o.gran.enabled = granNext() > 0;
        o.gran.attack = granNext() * .001f;
        o.gran.hold = granNext() * .001f;
        o.gran.grainSpacing = granNext();
        o.gran.waveSpacing = granNext();
        o.gran.pan = granNext();
        o.gran.depth = granNext();
        o.gran.frequency = granNext();
        o.gran.randomness = granNext();
        o.gran.transients = int(granNext());
        o.gran.transientHold = granNext() * .001f;
        o.gran.freeze = granNext() > 0;
        o.gran.keyTo = int(granNext());
        o.gran.sync = granNext() > 0;
        o.gran.beats = granNext();
    }
    for (int i = 0; i < partCount; ++i) {
        size_t at = partParamIndex(Param::p1input, i, 10);
        auto next = [&] { return get(Param(at++)); };
        auto &part = p.part[size_t(i)];
        part.input = int(next());
        part.filterType = int(next());
        part.slope = int(next());
        part.cutoff = next();
        part.resonance = next();
        part.drive = next();
        part.amp = {next(), next(), next(), next()};
        part.level = get(i == 0 ? Param::mixA : i == 1 ? Param::mixB : Param::mixC);
    }
    auto readRoutes = [&](size_t at) {
        Routes result{};
        for (auto &route : result) {
            route.destination = Destination(int(get(Param(at++))));
            route.amount = get(Param(at++));
        }
        return result;
    };
    for (int i = 0; i < 2; ++i) {
        size_t at = size_t(Param::env1a) + size_t(i) * 8;
        auto next = [&] { return get(Param(at++)); };
        p.envelopes[i] = {next(), next(), next(), next()};
        p.envelopeRoutes[i] = readRoutes(at);
        at = size_t(Param::lfo1wave) + size_t(i) * 10;
        auto &l = p.lfo[i];
        l.wave = int(next());
        l.rate = next();
        l.division = int(next());
        l.gain = next();
        l.offset = next();
        l.free = next() > 0;
        l.routes = readRoutes(at);
    }
    for (int i = 0; i < 4; ++i) {
        size_t at = size_t(Param::misc1source) + size_t(i) * 5;
        p.misc[i].source = Source(int(get(Param(at))));
        p.misc[i].routes = readRoutes(at + 1);
    }
    p.filterCutoff = get(Param::filtercutoff);
    p.filterResonance = get(Param::filterres);
    p.keytrack = get(Param::keytrack);
    p.warmDrive = get(Param::warmdrive) > 0;
    p.portamento = get(Param::portamento);
    p.portaMode = int(get(Param::portamode));
    p.bendRange = get(Param::bendrange);
    p.polyphony = effectivePolyphony();
    p.monoLegato = get(Param::monolegato) > 0;
    p.sync = get(Param::sync) > 0;
    p.solo = int(get(Param::solo));
    p.bpm = bpm;
    return p;
}
bool LogisthProcessor::setEffectOrder(EffectOrder order, bool notifyHost) {
    if (!order.valid())
        return false;
    if (effectOrderBits.exchange(order.packed()) != order.packed() && notifyHost)
        updateHostDisplay(
            AudioProcessorListener::ChangeDetails{}.withNonParameterStateChanged(true));
    return true;
}
bool LogisthProcessor::moveEffect(int from, int to) {
    auto order = effectOrder();
    return order.move(from, to) && setEffectOrder(order);
}
bool LogisthProcessor::setDistortionOrder(DistortionOrder order, bool notifyHost) {
    if (!order.valid())
        return false;
    if (distortionOrderBits.exchange(order.packed()) != order.packed() && notifyHost)
        updateHostDisplay(
            AudioProcessorListener::ChangeDetails{}.withNonParameterStateChanged(true));
    return true;
}
bool LogisthProcessor::moveDistortion(int from, int to) {
    auto order = distortionOrder();
    return order.move(from, to) && setDistortionOrder(order);
}
EffectsParams LogisthProcessor::effectsSnapshot() const {
    EffectsParams p;
    p.eqTrace = eqSpectrumEnabled.load(std::memory_order_relaxed) ? &eqSpectrum : nullptr;
    p.distortionTrace =
        distortionSpectrumEnabled.load(std::memory_order_relaxed) ? &distortionSpectrum : nullptr;
    p.distortion = get(Param::diston) > 0;
    p.distortionMultiband = get(Param::distbandmode) > 0;
    if (p.distortionMultiband) {
        p.distortionBands = int(get(Param::distbands)) + 1;
        p.distortionOrder = distortionOrder();
        for (int i = 0; i < 3; ++i)
            p.distortionCrossovers[size_t(i)] = get(Param(size_t(Param::distcross1) + size_t(i)));
        if (!p.distortion) {
            p.distortionType = int(get(Param::disttype));
            for (int i = 0; i < 3; ++i)
                p.extraDistortions[size_t(i)].type =
                    int(get(Param(size_t(Param::dist2type) + size_t(i) * 4)));
        }
    }
    p.phaser = get(Param::phaseron) > 0;
    p.chorus = get(Param::choruson) > 0;
    p.eq = get(Param::eqon) > 0;
    p.reverb = get(Param::reverbon) > 0;
    p.delay = get(Param::delayon) > 0;
    p.compressor = get(Param::compon) > 0;
    p.convolution = &impulseRack;
    if (!(p.distortion || p.phaser || p.chorus || p.eq || p.reverb || p.delay || p.compressor))
        return p;
    p.sync = get(Param::sync) > 0;
    p.dual = get(Param::chorusdual) > 0;
    p.pingpong = get(Param::delaypingpong) > 0;
    p.distortionType = int(get(Param::disttype));
    p.phaserDivision = int(get(Param::phaserdivision));
    p.chorusDivision = int(get(Param::chorusdivision));
    p.delayDivisionL = int(get(Param::delaydivL));
    p.delayDivisionR = int(get(Param::delaydivR));
    p.drive = get(Param::drive);
    p.distMix = get(Param::distmix);
    p.distortionOrder = distortionOrder();
    p.firstDistortionEnabled = get(Param::dist1on) > 0;
    for (int i = 0; i < 3; ++i) {
        const auto at = size_t(Param::dist2on) + size_t(i) * 4;
        p.extraDistortions[size_t(i)] = {get(Param(at)) > 0, int(get(Param(at + 1))),
                                         get(Param(at + 2)), get(Param(at + 3))};
    }
    p.phaserFreq = get(Param::phaserfreq);
    p.phaserSpread = get(Param::phaserspread);
    p.phaserOffset = get(Param::phaseroffset);
    p.phaserWidth = get(Param::phaserwidth);
    p.phaserRate = get(Param::phaserrate);
    p.phaserGain = get(Param::phasergain);
    p.phaserFeedback = get(Param::phaserfeedback);
    p.phaserMix = get(Param::phasermix);
    p.chorusDelay = get(Param::chorusdelay);
    p.chorusDepth = get(Param::chorusdepth);
    p.chorusRate = get(Param::chorusrate);
    p.chorusFeedback = get(Param::chorusfeedback);
    p.chorusWidth = get(Param::choruswidth);
    p.chorusMix = get(Param::chorus);
    p.eqMode = int(get(Param::eqmode));
    p.eqAutoGain = get(Param::eqautogain) > 0;
    p.eqOutput = get(Param::eqoutput);
    for (int i = 0; i < eqMaxBands; ++i) {
        auto n = size_t(i), at = size_t(eqBandTypes[n]);
        p.eqBands[n] = get(eqBandGains[n]);
        p.eqTypes[n] = int(get(Param(at)));
        p.eqFrequencies[n] = get(Param(at + 1));
        p.eqQ[n] = get(Param(at + 2));
        p.eqEnabled[n] = get(Param(at + 3)) > 0;
    }
    p.bass = get(Param::eqbass);
    p.bassFreq = get(Param::eqbassfreq);
    p.treble = get(Param::eqtreble);
    p.trebleFreq = get(Param::eqtreblefreq);
    p.reverbType = int(get(Param::reverbtype));
    p.convolution = &impulseRack;
    p.irNormalize = get(Param::irnormalize) > 0;
    p.reverbOutput = get(Param::reverbout);
    p.impulseSeconds = float(impulseDuration.load());
    p.modernCompressor = get(Param::compmode) > 0;
    p.compKnee = get(Param::compknee);
    p.compMakeup = get(Param::compmakeup);
    p.compMix = get(Param::compmix);
    p.reverbDecay = get(Param::reverbdecay);
    p.shimmerAmount = get(Param::shimmeramount);
    p.shimmerPitch = get(Param::shimmerpitch);
    p.springDispersion = get(Param::springdispersion);
    p.vintageMod = get(Param::vintagemod);
    p.reverbDiffusion = get(Param::reverbdiffusion);
    p.reverbSize = get(Param::reverbsize);
    p.reverbDamp = get(Param::reverbdamp);
    p.reverbPredelay = get(Param::reverbpredelay);
    p.reverbWidth = get(Param::reverbwidth);
    p.reverbMix = get(Param::reverb);
    p.delayL = get(Param::delaytime);
    p.delayR = get(Param::delayright);
    p.feedback = get(Param::feedback);
    p.delaySpread = get(Param::delayspread);
    p.delayWidth = get(Param::delaywidth);
    p.lowCut = get(Param::delaylowcut);
    p.highCut = get(Param::delayhighcut);
    p.smear = get(Param::delaysmear);
    p.delayMix = get(Param::delay);
    p.ratio = get(Param::compratio);
    p.threshold = get(Param::compthreshold);
    p.attack = get(Param::compattack);
    p.release = get(Param::comprelease);
    p.bpm = bpm;
    return p;
}
ArpParams LogisthProcessor::arpSnapshot() const {
    ArpParams p;
    p.enabled = get(Param::arpon) > 0;
    p.sync = get(Param::sync) > 0;
    p.mode = int(get(Param::arpmode));
    p.velocityMode = int(get(Param::arpvelocity));
    p.division = int(get(Param::arpdivision));
    p.octaves = int(get(Param::arpoctaves));
    p.wrap = int(get(Param::arpwrap));
    p.steps = int(get(Param::arpsteps));
    p.time = get(Param::arptime);
    p.gate = get(Param::arpgate);
    p.swing = get(Param::arpswing);
    for (int i = 0; i < 16; ++i) {
        size_t at = size_t(Param::step1transpose) + size_t(i) * 3;
        p.sequence[i] = {int(raw[at]->load()), int(raw[at + 1]->load()), raw[at + 2]->load() > 0};
    }
    p.pattern = get(Param::arppattern) > 0;
    p.latch = get(Param::arplatch) > 0;
    for (int i = 16; i < 32; ++i) {
        size_t at = size_t(Param::step17velocity) + size_t(i - 16) * 2;
        p.sequence[size_t(i)] = {0, int(raw[at]->load()), raw[at + 1]->load() > 0};
    }
    for (int i = 0; i < 32; ++i) {
        size_t at = size_t(Param::pat1note) + size_t(i) * 5;
        p.lanes[size_t(i)] = {int(raw[at]->load()), int(raw[at + 1]->load()),
                              int(raw[at + 2]->load()), int(raw[at + 3]->load()),
                              int(raw[at + 4]->load())};
    }
    for (int i = 0; i < 6; ++i)
        p.lengths[size_t(i)] = int(raw[size_t(Param::arpnotelen) + size_t(i)]->load());
    p.clockAvailable = clockAvailable;
    p.transportPlaying = wasPlaying;
    p.ppq = hostPpq;
    p.positionValid = hostPpqValid;
    p.bpm = bpm;
    return p;
}
void LogisthProcessor::prepareToPlay(double sampleRate, int blockSize) {
    setRateAndBufferSizeDetails(sampleRate, blockSize);
    const bool rateChanged = preparedSampleRate != sampleRate;
    impulseRate = sampleRate;
    if (rateChanged)
        impulseRack.detach();
    ensureImpulse(true);
    spectralRate = sampleRate;
    ensureSpectral(true);
    // Block capacity is negotiated by the host. Only a new clock rate invalidates
    // our time-domain state. Sound sources and DSP histories belong to this instance.
    if (!rateChanged)
        return;
    preparedSampleRate = sampleRate;
    generatedMidi.ensureSize(131072);
    engine.prepare(sampleRate);
    effects.prepare(sampleRate);
    arp.prepare(sampleRate);
    resetDsp();
}
void LogisthProcessor::reset() {
    // The VST3 wrapper maps setProcessing(false) to reset(), including when a host
    // temporarily suspends a playing graph to insert an instrument. The next audio
    // block supplies the transport information needed to distinguish this from a stop.
    if (wrapperType == wrapperType_VST3 && wasPlaying && expectedSample >= 0)
        pendingVstRestart = true;
    else
        resetDsp();
}
void LogisthProcessor::resetDsp() {
    pendingVstRestart = false;
    releaseOutputNotes = true;
    engine.reset();
    scope.clear();
    eqSpectrum.clear();
    distortionSpectrum.clear();
    lastEqCapture = lastDistortionCapture = false;
    for (auto &trace : playerScopes)
        trace.clear();
    chordMapper.reset();
    chordsWereEnabled = false;
    effects.reset();
    rackTransition.reset(getSampleRate(), effectOrder());
    clipper.reset();
    limiter.reset();
    dynamicsScope.clear();
    effectSamples = 0;
    for (auto &m : dynamicsMeters)
        m.write(0, 0, 0);
    impulseRack.reset();
    arp.reset();
    masterSmooth = get(Param::master);
    wasPlaying = false;
    expectedSample = -1;
    peak = 0;
    channelPeaks[0] = 0;
    channelPeaks[1] = 0;
    voices = 0;
}
void LogisthProcessor::OutputChannel::release(MidiBuffer &midi, int channel, int offset) {
    if (keys.any())
        for (int key = 0; key < 128; ++key)
            if (keys.test(size_t(key)))
                midi.addEvent(MidiMessage::noteOff(channel, key), offset);
    if (sustain)
        midi.addEvent(MidiMessage::controllerEvent(channel, 64, 0), offset);
    keys.reset();
    sustain = false;
}
void LogisthProcessor::processBlock(AudioBuffer<float> &audio, MidiBuffer &midi) {
    ScopedNoDenormals noDenormals;
    audio.clear();
    const int n = audio.getNumSamples();
    if (n <= 0 || audio.getNumChannels() < 2)
        return;
    struct AssetReadScope {
        std::atomic<int> &count;
        AssetReadScope(std::atomic<int> &c) : count(c) {
            count.fetch_add(1);
        }
        ~AssetReadScope() {
            count.fetch_sub(1);
        }
    } assetRead(assetReaders);
    generatedMidi.clear();
    bool stop = false, seek = false;
    clockAvailable = false;
    hostPpqValid = false;
    auto *head = getPlayHead();
    auto position = head ? head->getPosition() : Optional<AudioPlayHead::PositionInfo>{};
    if (pendingVstRestart) {
        pendingVstRestart = false;
        if (!position || !position->getIsPlaying() ||
            position->getTimeInSamples().orFallback(-1) != expectedSample)
            resetDsp();
    }
    if (position) {
        clockAvailable = true;
        if (auto ppq = position->getPpqPosition()) {
            hostPpq = *ppq;
            hostPpqValid = std::isfinite(hostPpq);
        }
        if (auto tempo = position->getBpm())
            if (std::isfinite(*tempo) && *tempo > 0)
                bpm = jlimit(20., 400., *tempo);
        stop = wasPlaying && !position->getIsPlaying();
        if (auto samples = position->getTimeInSamples()) {
            seek = wasPlaying && position->getIsPlaying() && expectedSample >= 0 &&
                   *samples != expectedSample;
            expectedSample = *samples + n;
        } else
            expectedSample = -1;
        wasPlaying = position->getIsPlaying();
    } else {
        expectedSample = -1;
        wasPlaying = false;
    }
    keyboard.processNextMidiBuffer(midi, 0, n, true);
    const bool midiOnly = get(Param::midionly) > 0;
    if (midiOnly != wasMidiOnly) {
        engine.silenceVoices();
        effects.reset();
        rackTransition.reset(getSampleRate(), effectOrder());
        clipper.reset();
        limiter.reset();
        wasMidiOnly = midiOnly;
    }
    const auto p = snapshot();
    const auto fx = effectsSnapshot();
    if (bool(fx.eqTrace) != lastEqCapture) {
        eqSpectrum.clear();
        lastEqCapture = bool(fx.eqTrace);
    }
    if (bool(fx.distortionTrace) != lastDistortionCapture) {
        distortionSpectrum.clear();
        lastDistortionCapture = bool(fx.distortionTrace);
    }
    rackTransition.request(effectOrder());
    const ClipperSettings cp{get(Param::clipon) > 0,    get(Param::clipquality) > 0,
                             int(get(Param::clipmode)), get(Param::clipdrive),
                             get(Param::clipceiling),   get(Param::clipknee),
                             get(Param::clipmix)};
    const LimiterSettings lp{get(Param::limiton) > 0, get(Param::limitceiling),
                             get(Param::limitrelease), get(Param::limitdrive)};
    const int display = dynamicsView.load(std::memory_order_relaxed);
    if (display != lastDynamicsDisplay) {
        dynamicsScope.clear();
        lastDynamicsDisplay = display;
    }
    uint64_t fxWork = 0;
    const auto ap = arpSnapshot();
    const float masterTarget = get(Param::master);
    const float smoothing = float(1 - std::exp(-1 / (.01 * getSampleRate())));
    int rendered = 0, scheduled = 0;
    float maximum = 0;
    std::array<float, 2> maxima{};
    auto renderTo = [&](int end) {
        while (rendered < end) {
            int count = rackTransition.blockLimit(jmin(512, end - rendered));
            auto *l = audio.getWritePointer(0) + rendered;
            auto *r = audio.getWritePointer(1) + rendered;
            if (midiOnly) {
                for (auto &m : dynamicsMeters)
                    m.write(0, 0, 0);
                dynamicsScope.clear();
                rendered += count;
                continue;
            }
            engine.render(l, r, count, p, driveMod.data(), phaserMod.data(), partScopeA.data(),
                          partScopeB.data(),
                          {playerTraces[0].data(), playerTraces[1].data(), playerTraces[2].data(),
                           playerTraces[3].data(), playerTraces[4].data(), playerTraces[5].data()},
                          partScopeC.data());
            auto orderedFx = fx;
            orderedFx.order = rackTransition.order();
            const ClipperStage clip{clipper, cp, dynamicsMeters[1],
                                    display == 1 ? &dynamicsScope : nullptr};
            effects.process(l, r, count, driveMod.data(), phaserMod.data(), orderedFx,
                            &dynamicsMeters[0], display == 0 ? &dynamicsScope : nullptr, &clip);
            fxWork += effects.processedSamples;
            std::array<float, 512> gains{};
            for (int i = 0; i < count; ++i) {
                masterSmooth += smoothing * (masterTarget - masterSmooth);
                const float outputGain = masterSmooth * rackTransition.tick();
                gains[size_t(i)] = outputGain;
                l[i] *= outputGain;
                r[i] *= outputGain;
            }
            limiter.process(l, r, count, lp, getSampleRate(), dynamicsMeters[2],
                            display == 2 ? &dynamicsScope : nullptr);
            for (int s = 0; s < count; ++s) {
                for (auto *ch : {l, r}) {
                    float x = ch[s];
                    ch[s] = std::isfinite(x) ? x : 0;
                    maximum = jmax(maximum, std::abs(ch[s]));
                    const size_t channel = ch == l ? 0 : 1;
                    maxima[channel] = jmax(maxima[channel], std::abs(ch[s]));
                }
                for (int slot = 0; slot < playerCount; ++slot)
                    playerScopes[size_t(slot)].push(0, 0, playerTraces[size_t(slot)][size_t(s)]);
                scope.push(partScopeA[size_t(s)] * gains[size_t(s)],
                           partScopeB[size_t(s)] * gains[size_t(s)], l[s] + r[s],
                           partScopeC[size_t(s)] * gains[size_t(s)]);
            }
            const auto &views = engine.playbackPictures();
            for (int i = 0; i < playerCount; ++i)
                playback[size_t(i)].write(views[size_t(i)]);
            rendered += count;
        }
    };
    const bool output = get(Param::arpout) > 0;
    const bool flushMidi = midiWasEnabled && (!output || releaseOutputNotes);
    releaseOutputNotes = false;
    if (flushMidi)
        for (int ch = 1; ch <= 16; ++ch)
            outputChannels[size_t(ch - 1)].release(generatedMidi, ch, 0);
    midiWasEnabled = output;
    auto emit = [&](MidiEvent event) {
        if (p.fixedVelocity && event.type == EventType::NoteOn)
            event.value = 1;
        if (output && event.time < n) {
            auto &sent = outputChannels[size_t(event.channel - 1)];
            if (event.localCleanup)
                sent.release(generatedMidi, event.channel, event.time);
            else if (event.type == EventType::NoteOn) {
                sent.keys.set(size_t(event.key));
                generatedMidi.addEvent(MidiMessage::noteOn(event.channel, event.key, event.value),
                                       event.time);
            } else if (event.type == EventType::NoteOff) {
                sent.keys.reset(size_t(event.key));
                generatedMidi.addEvent(MidiMessage::noteOff(event.channel, event.key), event.time);
            } else if (event.type == EventType::Controller) {
                if (event.key == 64)
                    sent.sustain = event.value >= 64;
                if (event.key == 120 || event.key == 123)
                    sent.keys.reset();
                generatedMidi.addEvent(
                    MidiMessage::controllerEvent(event.channel, event.key, int(event.value)),
                    event.time);
            } else if (event.type == EventType::PitchWheel)
                generatedMidi.addEvent(
                    MidiMessage::pitchWheel(event.channel,
                                            jlimit(0, 16383, int(event.value * 8192 + 8192))),
                    event.time);
            else if (event.type == EventType::Aftertouch)
                generatedMidi.addEvent(
                    event.key < 0
                        ? MidiMessage::channelPressureChange(event.channel, int(event.value * 127))
                        : MidiMessage::aftertouchChange(event.channel, event.key,
                                                        int(event.value * 127)),
                    event.time);
        }
        renderTo(jlimit(rendered, n, event.time));
        if (midiOnly && (event.type == EventType::NoteOn || event.type == EventType::NoteOff))
            return;
        switch (event.type) {
        case EventType::NoteOn:
            engine.noteOn(event.key, event.value, event.channel, p);
            break;
        case EventType::NoteOff:
            engine.noteOff(event.key, event.channel, p);
            break;
        case EventType::Controller:
            engine.controller(event.channel, event.key, int(event.value), p);
            break;
        case EventType::PitchWheel:
            engine.pitchWheel(event.channel, event.value);
            break;
        case EventType::Aftertouch:
            engine.aftertouch(event.channel, event.key, event.value);
            break;
        case EventType::StepVelocity:
            engine.setStepVelocity(event.value);
            break;
        }
    };
    arp.begin(ap, emit);
    const bool chordEnabled = get(Param::chordon) > 0;
    if (stop || seek || chordsWereEnabled != chordEnabled) {
        arp.stop(0, emit);
        chordMapper.reset();
    }
    chordsWereEnabled = chordEnabled;
    int changes = uiChanges.exchange(0);
    if (changes & 4) {
        arp.stop(0, emit);
        chordMapper.reset();
    }
    auto mapped = [&](MidiEvent event) { arp.input(event, ap, emit); };
    if (changes & 1)
        arp.input(MidiEvent{0, EventType::PitchWheel, 1, 0, pitchPosition.load()}, ap, emit);
    if (changes & 2)
        arp.input(MidiEvent{0, EventType::Controller, 1, 1, wheelPosition.load() * 127}, ap, emit);
    for (const auto metadata : midi) {
        int offset = jlimit(scheduled, n, metadata.samplePosition);
        arp.advance(scheduled, offset, ap, emit);
        scheduled = offset;
        auto m = metadata.getMessage();
        MidiEvent event;
        event.time = offset;
        event.channel = m.getChannel();
        if (m.isNoteOn()) {
            event.type = EventType::NoteOn;
            event.key = m.getNoteNumber();
            event.value = m.getFloatVelocity();
        } else if (m.isNoteOff()) {
            event.type = EventType::NoteOff;
            event.key = m.getNoteNumber();
        } else if (m.isController()) {
            event.type = EventType::Controller;
            event.key = m.getControllerNumber();
            event.value = float(m.getControllerValue());
        } else if (m.isPitchWheel()) {
            event.type = EventType::PitchWheel;
            event.value = (m.getPitchWheelValue() - 8192) / 8192.f;
        } else if (m.isAftertouch()) {
            event.type = EventType::Aftertouch;
            event.key = m.getNoteNumber();
            event.value = m.getAfterTouchValue() / 127.f;
        } else if (m.isChannelPressure()) {
            event.type = EventType::Aftertouch;
            event.key = -1;
            event.value = m.getChannelPressureValue() / 127.f;
        } else {
            if (output && m.getRawDataSize() <= 4096)
                generatedMidi.addEvent(m, offset);
            continue;
        }
        if (event.type == EventType::PitchWheel)
            pitchPosition = event.value;
        if (event.type == EventType::Controller && event.key == 1)
            wheelPosition = event.value / 127.f;
        const int learn = learnTarget.load();
        if (learn >= 0 && (event.type == EventType::NoteOn || event.type == EventType::NoteOff)) {
            if (event.type == EventType::NoteOn)
                learned[size_t(event.key / 32)].fetch_or(uint32_t(1) << (event.key % 32));
            continue;
        }
        chordMapper.input(event, chordEnabled, *chordPointer.load(), mapped);
    }
    arp.advance(scheduled, n, ap, emit);
    renderTo(n);
    effectSamples = fxWork;
    scope.commit();
    for (auto &trace : playerScopes)
        trace.commit();
    arpPlayhead = arp.playhead();
    midi.clear();
    if (output || flushMidi)
        midi.swapWith(generatedMidi);
    peak = maximum;
    channelPeaks[0] = maxima[0];
    channelPeaks[1] = maxima[1];
    voices = engine.activeVoices();
}
void LogisthProcessor::getStateInformation(MemoryBlock &dest) try {
    auto tree = state.copyState();
    tree.setProperty("schema", 4, nullptr);
    tree.setProperty("presetName", currentPresetName(), nullptr);
    tree.setProperty("presetComment", presetComment(), nullptr);
    saveMacroMetadata(tree);
    saveAssets(tree);
    copyXmlToBinary(*tree.createXml(), dest);
    if (dest.getSize() > size_t(stateMemoryLimit))
        dest.reset();
} catch (const std::bad_alloc &) {
    dest.reset();
}
void LogisthProcessor::setStateInformation(const void *data, int size) {
    applyState(data, size);
}
bool LogisthProcessor::applyState(const void *data, int size) try {
    if (size <= 0 || size > stateMemoryLimit)
        return false;
    auto xml = getXmlFromBinary(data, size);
    if (!xml)
        return false;
    auto restore = [&](const ValueTree &source) -> bool {
        ValueTree safe("LogisthState");
        safe.setProperty("schema", 4, nullptr);
        if (source.hasProperty("uiScope"))
            safe.setProperty("uiScope", jlimit(0, 3, int(source["uiScope"])), nullptr);
        for (const auto &spec : parameterSpecs) {
            float value = (String(spec.id) == "arppattern" || String(spec.id).endsWith("gmodel") ||
                           String(spec.id) == "compmode")
                              ? 0
                              : spec.initial;
            for (auto child : source)
                if (child["id"].toString() == spec.id) {
                    value = float(child["value"]);
                    break;
                }
            if (!std::isfinite(value))
                value = spec.initial;
            value = jlimit(spec.low, spec.high, value);
            if (spec.integer || *spec.choices)
                value = std::round(value);
            ValueTree child("PARAM");
            child.setProperty("id", spec.id, nullptr);
            child.setProperty("value", value, nullptr);
            safe.addChild(child, -1, nullptr);
        }
        if (!restoreAssets(source))
            return false;
        state.replaceState(safe);
        for (int i = 0; i < 4; ++i)
            setMacroName(
                i,
                source.getProperty("macroName" + String(i), "Macro " + String(i + 1)).toString());
        mutateLocks = jlimit(0, 15, int(source.getProperty("mutateLocks", 0)));
        {
            const ScopedLock lock(assetLock);
            mutationUndo.reset();
        }
        {
            const ScopedLock lock(assetLock);
            presetName = source.getProperty("presetName", "").toString().substring(0, 128);
            comment = source.getProperty("presetComment", "").toString().substring(0, 4096);
            ++commentRevision;
            activePresetFile = File{};
        }
        ++presetRevision;
        uiChanges.fetch_or(4);
        return true;
    };
    if (xml->hasTagName(state.state.getType())) {
        return restore(ValueTree::fromXml(*xml));
    }
    // Import the previous prototype's state without retaining its product identity.
    if (!xml->hasTagName("AsterionState"))
        return false;
    const auto old = ValueTree::fromXml(*xml);
    ValueTree migrated("LogisthState");
    auto oldValue = [&](const String &id, float fallback) {
        for (auto child : old)
            if (child["id"].toString() == id)
                return float(child["value"]);
        return fallback;
    };
    for (const auto &spec : parameterSpecs) {
        ValueTree parameter("PARAM");
        parameter.setProperty("id", spec.id, nullptr);
        parameter.setProperty("value", oldValue(spec.id, spec.initial), nullptr);
        migrated.addChild(parameter, -1, nullptr);
    }
    auto set = [&](const String &id, float value) {
        for (auto child : migrated)
            if (child["id"].toString() == id)
                child.setProperty("value", value, nullptr);
    };
    for (int i = 1; i <= 2; ++i) {
        String part = "p" + String(i), env = "env" + String(i);
        for (auto s : {"a", "d", "s", "r"})
            set(env + s, oldValue(part + "flt" + s, String(s) == "s" ? 0.f : .25f));
        set(env + "amt1", oldValue(part + "env", 24) / 12);
        set(i == 1 ? "mixA" : "mixB", oldValue(part + "level", .7f));
    }
    set("arppattern", 0);
    set("lfo1dest1", 15);
    set("lfo1amt1", oldValue("lfo1depth", 0) / 12);
    set("lfo2dest1", 6);
    set("lfo2amt1", oldValue("lfo2depth", 0) / 4.8f);
    set("diston", oldValue("drive", 0) > 0 ? 1 : 0);
    set("choruson", oldValue("chorus", 0) > 0 ? 1 : 0);
    set("delayon", oldValue("delay", 0) > 0 ? 1 : 0);
    return restore(migrated);
} catch (const std::bad_alloc &) {
    return false;
}
void LogisthProcessor::loadPreset(int index) {
    setEffectOrder(EffectOrder{}, false);
    setDistortionOrder(DistortionOrder{}, false);
    if (index >= 10 && index < factoryPresetCount) {
        loadPreset(0);
        auto set = [&](const char *id, float value) {
            auto *parameter = state.getParameter(id);
            jassert(parameter != nullptr);
            if (parameter)
                parameter->setValueNotifyingHost(parameter->convertTo0to1(value));
        };
        applyDesignedSound(index - 10, set);
        const auto &sound = designedSounds[size_t(index - 10)];
        {
            const ScopedLock lock(assetLock);
            presetName = sound.name;
            comment = sound.description;
            ++commentRevision;
        }
        // Each new patch has four useful, neutral-at-zero performance controls.
        const std::array<Param, 4> targets{
            Param::filtercutoff, Param::o1fmdepth, Param::o1pulsewidth,
            raw[size_t(Param::reverbon)]->load() > 0  ? Param::reverb
            : raw[size_t(Param::delayon)]->load() > 0 ? Param::delay
                                                      : Param::drive};
        const int routes[]{1, 12, 8,
                           raw[size_t(Param::reverbon)]->load() > 0  ? 20
                           : raw[size_t(Param::delayon)]->load() > 0 ? 22
                                                                     : 23};
        for (int macro = 0; macro < 4; ++macro) {
            setMacroName(macro, StringArray{"Brightness", "Harmonics", "Warp",
                                            routes[macro] == 23 ? "Drive" : "Space"}[macro]);
            auto prefix = "m" + String(macro + 1);
            auto *parameter = state.getParameter(parameterSpecs[size_t(targets[size_t(macro)])].id);
            float base = parameter->getValue();
            set((prefix + "target1").toRawUTF8(), float(routes[macro]));
            set((prefix + "low1").toRawUTF8(), base);
            set((prefix + "high1").toRawUTF8(), jmin(1.f, base + (macro == 0 ? .16f : .2f)));
        }
        ++presetRevision;
        uiChanges.fetch_or(4);
        return;
    }
    mutationUndo.reset();
    mutateLocks = 0;
    for (int i = 0; i < 4; ++i)
        setMacroName(i, "Macro " + String(i + 1));
    for (auto *parameter : getParameters()) {
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost(parameter->getDefaultValue());
        parameter->endChangeGesture();
    }
    {
        const ScopedLock lock(assetLock);
        presetName = legacyFactoryNames[size_t(jlimit(0, 9, index))];
        comment.clear();
        ++commentRevision;
        activePresetFile = File{};
        patterns = {};
        currentPattern = 0;
    }
    for (int i = 0; i < playerCount; ++i)
        clearSource(i);
    clearImpulse();
    auto defaultChords = std::make_shared<ChordMap>();
    for (int key = 0; key < 128; ++key)
        defaultChords->set(key, 1);
    publishChords(defaultChords);
    ++presetRevision;
    auto set = [&](const String &id, float value) {
        auto *parameter = state.getParameter(id);
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost(parameter->convertTo0to1(value));
        parameter->endChangeGesture();
    };
    if (index == 0) {
        for (int i = 1; i <= playerCount; ++i) {
            auto id = "o" + String(i);
            set(id + "engine", 0);
            set(id + "wave", 1);
            set(id + "voices", 1);
            set(id + "level", i == 1 ? .65f : 0);
            set(id + "octave", 0);
            set(id + "tune", 0);
            set(id + "fine", 0);
            set(id + "pan", 0);
            set(id + "detune", 0);
            set(id + "stereo", 0);
            set(id + "envelope", 0);
        }
        for (int i = 1; i <= partCount; ++i) {
            auto id = "p" + String(i);
            set(id + "type", 3);
            set(id + "res", 0);
            set(id + "ampa", 0);
            set(id + "ampd", 0);
            set(id + "amps", 1);
            set(id + "ampr", .01f);
        }
        for (const auto &spec : parameterSpecs) {
            String id(spec.id);
            if (id.contains("dest") || id.contains("amt"))
                set(id, 0);
        }
        for (auto id : {"arpon", "chordon", "diston", "phaseron", "choruson", "eqon", "reverbon",
                        "delayon", "compon"})
            set(id, 0);
    }
    if (index == 1) {
        set("o1voices", 7);
        set("o1detune", 18);
        set("o2voices", 5);
        set("o2tune", 0);
        set("o2level", .5f);
        set("choruson", 1);
        set("chorus", .25f);
        set("delayon", 1);
        set("delay", .3f);
        set("reverb", .25f);
    }
    if (index == 2) {
        set("o1wave", 2);
        set("o2wave", 0);
        set("p1cutoff", 500);
        set("p1res", .55f);
        set("env1amt1", 4);
        set("p1ampa", .002f);
        set("p1amps", .45f);
        set("env1d", .15f);
        set("diston", 1);
        set("drive", .25f);
        set("reverbon", 0);
    }
    if (index == 3) {
        set("o1voices", 5);
        set("o3level", .5f);
        set("o3voices", 7);
        set("o3tune", 12);
        for (int i = 1; i <= 2; ++i) {
            auto id = "p" + String(i);
            set(id + "ampa", 1.2f);
            set(id + "ampr", 2.5f);
            set(id + "cutoff", 1800);
        }
        set("lfo1dest1", 15);
        set("lfo1amt1", .7f);
        set("lfo1free", 1);
        set("lfo1rate", .2f);
        set("choruson", 1);
        set("chorus", .6f);
        set("reverb", .4f);
    }
    if (index == 4) {
        set("o1wave", 2);
        set("o1voices", 3);
        set("p1cutoff", 1200);
        set("env1amt1", 4);
        set("p1amps", 0);
        set("p1ampd", .22f);
        set("p1ampr", .12f);
        set("env1d", .12f);
        set("delayon", 1);
        set("delay", .3f);
    }
    if (index == 5) {
        set("arppattern", 0);
        set("arpon", 1);
        set("arpmode", 8);
        set("arpsteps", 8);
        for (int i = 1; i <= 8; ++i) {
            set("step" + String(i) + "transpose", i % 2 ? 0 : 12);
            set("step" + String(i) + "velocity", 70 + i * 6);
        }
        set("p1cutoff", 900);
        set("env1amt1", 4);
        set("env1d", .12f);
        set("p1ampd", .2f);
        set("p1amps", .2f);
        set("delayon", 1);
        set("delay", .2f);
    }
    if (index >= 6 && index <= 9) {
        clearSource(0);
        set("o2level", 0);
        set("p1cutoff", 8500);
        set("env1amt1", 0);
        if (index == 6) {
            set("o1engine", 1);
            set("o1position", .55f);
            set("o1voices", 3);
            set("lfo1dest1", 28);
            set("lfo1amt1", 2);
            set("lfo1free", 1);
            set("lfo1rate", .2f);
        }
        if (index == 7) {
            set("o1engine", 2);
            set("o1loop", 0);
            set("p1ampr", .8f);
        }
        if (index == 8) {
            set("o1gmodel", 0);
            set("o1engine", 3);
            set("o1position", .2f);
            set("o1size", 140);
            set("o1density", 28);
            set("o1spray", .5f);
            set("o1scan", .15f);
            set("p1ampa", .5f);
            set("p1ampr", 1.8f);
            set("reverb", .5f);
        }
        if (index == 9) {
            set("o1engine", 1);
            set("o1position", .75f);
            set("arpon", 1);
            set("arppattern", 1);
            set("chordon", 1);
            set("p1amps", .15f);
            set("p1ampd", .15f);
            set("delayon", 1);
            set("delay", .25f);
        }
    }
    set("master", factoryMainLevels[size_t(jlimit(0, 9, index))]);
    uiChanges.fetch_or(4);
}
AudioProcessorEditor *LogisthProcessor::createEditor() {
    return new LogisthEditor(*this);
}
AudioProcessor *JUCE_CALLTYPE createPluginFilter() {
    return new LogisthProcessor();
}

String LogisthProcessor::macroName(int index) const {
    const ScopedLock lock(assetLock);
    return macroNames[size_t(jlimit(0, 3, index))];
}
void LogisthProcessor::setMacroName(int index, const String &name) {
    const ScopedLock lock(assetLock);
    auto clean = name.trim().substring(0, 24);
    macroNames[size_t(jlimit(0, 3, index))] =
        clean.isEmpty() ? "Macro " + String(index + 1) : clean;
    ++macroRevision;
}
void LogisthProcessor::mutate(uint64_t seed) {
    const ScopedLock lock(assetLock);
    std::array<float, parameterCount> before{};
    for (size_t i = 0; i < parameterCount; ++i)
        before[i] = state.getParameter(parameterSpecs[i].id)->getValue();
    mutationUndo = before;
    Random random(seed ? int64(seed) : Time::getHighResolutionTicks());
    float depth = raw[size_t(Param::mutateamount)]->load();
    for (size_t i = 0; i < parameterCount; ++i) {
        String id(parameterSpecs[i].id), group(parameterSpecs[i].group);
        int section =
            group.startsWith("OSC") || group.startsWith("SOURCE") ? 0
            : group.startsWith("FILTER")                          ? 1
            : group.startsWith("LFO") || group.startsWith("MOD ENV") || group.startsWith("MISC")
                ? 2
                : 3;
        if (mutateLocks & (1 << section))
            continue;
        // Only continuous timbre controls: retain sample files, engines, note timing,
        // levels, routing choices and MIDI/transport behaviour.
        bool eligible = id.endsWith("detune") || id.endsWith("stereo") || id.endsWith("phase") ||
                        id.endsWith("position") || id.endsWith("pulsewidth") ||
                        id.endsWith("pwmdepth") || id.endsWith("fmdepth") ||
                        id.endsWith("amdepth") || id.endsWith("cutoff") || id.endsWith("res") ||
                        id == "filtercutoff" || id == "filterres" || id == "reverb" ||
                        id == "reverbdecay" || id == "reverbdiffusion" || id == "delay" ||
                        id == "drive" || id == "chorus" || id == "lfo1rate" || id == "lfo2rate";
        if (id.endsWith("position") && id.startsWith("o")) {
            auto engineId = id.substring(0, 2) + "engine";
            if (auto *engine = state.getRawParameterValue(engineId); engine && engine->load() == 2)
                eligible = false;
        }
        if (!eligible)
            continue;
        auto *param = state.getParameter(parameterSpecs[i].id);
        param->beginChangeGesture();
        param->setValueNotifyingHost(
            jlimit(0.f, 1.f, before[i] + (random.nextFloat() * 2 - 1) * depth * .25f));
        param->endChangeGesture();
    }
}
void LogisthProcessor::undoMutation() {
    const ScopedLock lock(assetLock);
    if (!mutationUndo)
        return;
    auto before = *mutationUndo;
    mutationUndo.reset();
    for (size_t i = 0; i < parameterCount; ++i) {
        auto *param = state.getParameter(parameterSpecs[i].id);
        if (std::abs(param->getValue() - before[i]) < 1e-7f)
            continue;
        param->beginChangeGesture();
        param->setValueNotifyingHost(before[i]);
        param->endChangeGesture();
    }
}

void LogisthProcessor::saveMacroMetadata(ValueTree &tree) const {
    const ScopedLock lock(assetLock);
    for (int i = 0; i < 4; ++i)
        tree.setProperty("macroName" + String(i), macroNames[size_t(i)], nullptr);
    tree.setProperty("mutateLocks", mutateLocks.load(), nullptr);
}
