#pragma once
#include "Topology.h"
#include <algorithm>
#include <array>
#include <cmath>
namespace logisth {
constexpr double pi = 3.14159265358979323846;
inline float clamp(float x, float lo, float hi) {
    return std::clamp(x, lo, hi);
}
enum class Destination {
    None,
    VolumeA,
    VolumeB,
    VolumeAB,
    PitchA,
    PitchB,
    PitchAB,
    PhaseA,
    PhaseB,
    PhaseAB,
    PanA,
    PanB,
    PanAB,
    CutoffA,
    CutoffB,
    CutoffAB,
    ResonanceA,
    ResonanceB,
    ResonanceAB,
    PhaserFrequency,
    MixA,
    MixB,
    MixAB,
    Lfo1Rate,
    Lfo1Gain,
    Lfo2Rate,
    Lfo2Gain,
    DistortionAmount,
    PositionA,
    PositionB,
    PositionAB,
    GrainSizeA,
    GrainSizeB,
    GrainSizeAB,
    PositionA1,
    PositionA2,
    PositionB1,
    PositionB2,
    FmA1,
    FmA2,
    FmB1,
    FmB2,
    FmA,
    FmB,
    FmAB,
    AmA1,
    AmA2,
    AmB1,
    AmB2,
    AmA,
    AmB,
    AmAB,
    WidthA1,
    WidthA2,
    WidthB1,
    WidthB2,
    WidthA,
    WidthB,
    WidthAB,
    VolumeC,
    VolumeABC,
    PitchC,
    PitchABC,
    PhaseC,
    PhaseABC,
    PanC,
    PanABC,
    CutoffC,
    CutoffABC,
    ResonanceC,
    ResonanceABC,
    MixC,
    MixABC,
    PositionC,
    PositionABC,
    GrainSizeC,
    GrainSizeABC,
    PositionC1,
    PositionC2,
    FmC1,
    FmC2,
    FmC,
    FmABC,
    AmC1,
    AmC2,
    AmC,
    AmABC,
    WidthC1,
    WidthC2,
    WidthC,
    WidthABC,
    VolumeAC,
    VolumeBC,
    PitchAC,
    PitchBC,
    PhaseAC,
    PhaseBC,
    PanAC,
    PanBC,
    CutoffAC,
    CutoffBC,
    ResonanceAC,
    ResonanceBC,
    MixAC,
    MixBC,
    PositionAC,
    PositionBC,
    GrainSizeAC,
    GrainSizeBC,
    FmAC,
    FmBC,
    AmAC,
    AmBC,
    WidthAC,
    WidthBC,
    Count
};
enum class Source {
    None,
    Velocity,
    Keytrack,
    Aftertouch,
    ModWheel,
    PitchWheel,
    AmpEnvA,
    AmpEnvB,
    ModEnv1,
    ModEnv2,
    Lfo1,
    Lfo2,
    StepVelocity,
    Random,
    RandomBipolar,
    AmpEnvC,
    Count
};
struct Route {
    Destination destination = Destination::None;
    float amount = 0;
};
using Routes = std::array<Route, 2>;
struct Misc {
    Source source = Source::None;
    Routes routes{};
};
struct ModValues {
    std::array<float, size_t(Destination::Count)> values{};
    float get(Destination d) const {
        return values[size_t(d)];
    }
    void add(const Routes &routes, float source) {
        for (const auto &r : routes)
            if (r.destination != Destination::None)
                values[size_t(r.destination)] += source * r.amount * .1f;
    }
    float osc(Destination first, int slot) const {
        const auto c = first == Destination::FmA1   ? Destination::FmC1
                       : first == Destination::AmA1 ? Destination::AmC1
                                                    : Destination::WidthC1;
        const auto paired = first == Destination::FmA1   ? Destination::FmAC
                            : first == Destination::AmA1 ? Destination::AmAC
                                                         : Destination::WidthAC;
        const int part = slot / 2;
        const float group =
            (part != 1 ? get(paired) : 0) + (part != 0 ? get(Destination(int(paired) + 1)) : 0);
        if (slot < 4)
            return group + get(Destination(int(first) + slot)) +
                   get(Destination(int(first) + 4 + slot / 2)) + get(Destination(int(first) + 6)) +
                   get(Destination(int(c) + 3));
        return group + get(Destination(int(c) + slot - 4)) + get(Destination(int(c) + 2)) +
               get(Destination(int(c) + 3));
    }
    float position(int slot) const {
        return pair(Destination::PositionA, slot / 2) +
               get(slot < 4 ? Destination(int(Destination::PositionA1) + slot)
                            : Destination(int(Destination::PositionC1) + slot - 4));
    }
    float pair(Destination first, int part) const {
        Destination c = Destination::None, pair = Destination::None;
        switch (first) {
        case Destination::VolumeA:
            c = Destination::VolumeC;
            pair = Destination::VolumeAC;
            break;
        case Destination::PitchA:
            c = Destination::PitchC;
            pair = Destination::PitchAC;
            break;
        case Destination::PhaseA:
            c = Destination::PhaseC;
            pair = Destination::PhaseAC;
            break;
        case Destination::PanA:
            c = Destination::PanC;
            pair = Destination::PanAC;
            break;
        case Destination::CutoffA:
            c = Destination::CutoffC;
            pair = Destination::CutoffAC;
            break;
        case Destination::ResonanceA:
            c = Destination::ResonanceC;
            pair = Destination::ResonanceAC;
            break;
        case Destination::MixA:
            c = Destination::MixC;
            pair = Destination::MixAC;
            break;
        case Destination::PositionA:
            c = Destination::PositionC;
            pair = Destination::PositionAC;
            break;
        case Destination::GrainSizeA:
            c = Destination::GrainSizeC;
            pair = Destination::GrainSizeAC;
            break;
        default:
            return 0;
        }
        const float all = get(Destination(int(c) + 1)) + (part != 1 ? get(pair) : 0) +
                          (part != 0 ? get(Destination(int(pair) + 1)) : 0);
        return part < 2
                   ? get(Destination(int(first) + part)) + get(Destination(int(first) + 2)) + all
                   : get(c) + all;
    }
};
struct EnvelopeParams {
    float attack = .008f, decay = .25f, sustain = .7f, release = .35f;
};
struct LfoParams {
    int wave = 0, division = 7;
    float rate = 1, gain = 1, offset = 0;
    bool free = false;
    Routes routes{};
};
// Beat lengths: straight, triplet and dotted values, indexed by the UI menu.
inline constexpr std::array<double, 16> beatLengths{.0625,
                                                    .0833333333333,
                                                    .125,
                                                    .166666666667,
                                                    .25,
                                                    .375,
                                                    .333333333333,
                                                    .5,
                                                    .75,
                                                    .666666666667,
                                                    1,
                                                    1.5,
                                                    2,
                                                    4,
                                                    8,
                                                    16};
inline double beatLength(int index) {
    return beatLengths[size_t(std::clamp(index, 0, 15))];
}
inline double lfoRate(const LfoParams &p, bool sync, double bpm) {
    return sync && !p.free ? bpm / (60 * beatLength(p.division)) : p.rate;
}
inline float lfoWave(double phase, int wave, float held, float next) {
    const float t = float(phase);
    switch (wave) {
    case 0:
        return float(std::sin(2 * pi * phase));
    case 1:
        return 1 - 4 * std::abs(t - .5f);
    case 2:
        return 2 * t - 1;
    case 3:
        return 1 - 2 * t;
    case 4:
        return t < .5f ? 1 : -1;
    case 5:
        return t < .25f ? 1 : -1;
    case 6:
        return held;
    case 7:
        return held + (next - held) * t * t * (3 - 2 * t);
    case 8:
        return .5f + .5f * float(std::sin(2 * pi * phase));
    default:
        return 1 - 2 * std::abs(t - .5f);
    }
}
} // namespace logisth
