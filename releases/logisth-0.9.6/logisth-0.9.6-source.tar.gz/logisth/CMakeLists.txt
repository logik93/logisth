cmake_minimum_required(VERSION 3.22)
project(Logisth VERSION 0.9.6 LANGUAGES C CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
include(CTest)
option(LOGISTH_PLUGINS "Build JUCE plug-ins" ON)
option(LOGISTH_VST2 "Build VST2 using your licensed SDK" OFF)
set(VST2_SDK_PATH "" CACHE PATH "Path to licensed VST2 SDK")
if(BUILD_TESTING)
  find_package(Threads REQUIRED)
  add_executable(engine_tests tests/EngineTests.cpp)
  target_include_directories(engine_tests PRIVATE Source)
  add_test(NAME engine COMMAND engine_tests)
  foreach(suite IN ITEMS Modulation Arpeggiator Hybrid Studio Reverb Advanced Performance StretchControls PartC TailLoop Unison FlexibleEQ)
    add_executable(${suite}_tests tests/${suite}Tests.cpp)
    target_include_directories(${suite}_tests PRIVATE Source)
    add_test(NAME ${suite} COMMAND ${suite}_tests)
  endforeach()
  target_sources(Performance_tests PRIVATE tests/SmallStackRegression.cpp)
  target_link_libraries(Performance_tests PRIVATE Threads::Threads)
  find_package(Python3 REQUIRED COMPONENTS Interpreter)
  add_executable(legacy_audio_capture tests/LegacyAudioCapture.cpp)
  target_include_directories(legacy_audio_capture PRIVATE tests/fixtures/legacy-0.9.4.1 Source)
  add_executable(current_audio_capture tests/LegacyAudioCapture.cpp)
  target_include_directories(current_audio_capture PRIVATE Source)
  add_test(NAME LegacyAudioCompatibility COMMAND ${Python3_EXECUTABLE}
    ${CMAKE_CURRENT_SOURCE_DIR}/scripts/check_legacy_audio.py
    $<TARGET_FILE:legacy_audio_capture> $<TARGET_FILE:current_audio_capture>)

endif()
if(NOT LOGISTH_PLUGINS)
  return()
endif()
include(FetchContent)
FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git GIT_TAG 51a8a6d7aeae7326956d747737ccf1575e61e209 GIT_SHALLOW FALSE)
FetchContent_MakeAvailable(JUCE)
set(formats VST3 Standalone)
if(LOGISTH_VST2)
  if(NOT EXISTS "${VST2_SDK_PATH}/pluginterfaces/vst2.x/aeffect.h")
    message(FATAL_ERROR "VST2 needs your licensed SDK with pluginterfaces/vst2.x/aeffect.h. See README.md.")
  endif()
  juce_set_vst2_sdk_path("${VST2_SDK_PATH}")
  list(APPEND formats VST)
endif()
# Keep the full release string in plug-in metadata, with legal three-part Apple
# bundle versions. The internal build tuple remains ordered for future releases.
math(EXPR logisth_apple_major "${PROJECT_VERSION_MAJOR} * 100 + ${PROJECT_VERSION_MINOR}")
set(logisth_revision 0)
if(NOT "${PROJECT_VERSION_TWEAK}" STREQUAL "")
  set(logisth_revision "${PROJECT_VERSION_TWEAK}")
endif()
set(logisth_apple_build "${logisth_apple_major}.${PROJECT_VERSION_PATCH}.${logisth_revision}")
set(logisth_marketing "${PROJECT_VERSION_MAJOR}.${PROJECT_VERSION_MINOR}.${PROJECT_VERSION_PATCH}")
set(logisth_bundle_options)
if(APPLE)
  set(logisth_bundle_options BUILD_VERSION "${logisth_apple_build}" PLIST_TO_MERGE
    "<plist><dict><key>CFBundleShortVersionString</key><string>${logisth_marketing}</string><key>CFBundleGetInfoString</key><string>logisth ${PROJECT_VERSION}</string></dict></plist>")
endif()
juce_add_plugin(Logisth ${logisth_bundle_options} COMPANY_NAME "wavelogik" BUNDLE_ID "com.wavelogik.logisth"
  PLUGIN_MANUFACTURER_CODE Wvlg PLUGIN_CODE Lgst
  FORMATS ${formats} PRODUCT_NAME "logisth"
  IS_SYNTH TRUE NEEDS_MIDI_INPUT TRUE NEEDS_MIDI_OUTPUT TRUE
  IS_MIDI_EFFECT FALSE EDITOR_WANTS_KEYBOARD_FOCUS FALSE
  COPY_PLUGIN_AFTER_BUILD FALSE VST3_CATEGORIES Instrument Synth)
juce_add_binary_data(LogisthFonts SOURCES
  assets/fonts/OpenSans-Regular.ttf assets/fonts/OpenSans-Semibold.ttf
  assets/fonts/ioskeley/IoskeleyMonoTermNerdFontMono-Regular.ttf
  assets/fonts/ioskeley/IoskeleyMonoTermNerdFontMono-Bold.ttf
  assets/themes/bokkenmmb-Solarized.json "assets/themes/bokkenmmb-Tokyo Night.json"
  "assets/themes/bokkenmmb-Solarized Osaka.json" assets/themes/bokkenmmb-gruvbox.json assets/skins/ap-music-group-white.png)
target_sources(Logisth PRIVATE Source/PluginProcessor.cpp Source/SourceAssets.cpp Source/PresetLibrary.cpp Source/PluginEditor.cpp Source/ThemeSettings.cpp)
target_link_libraries(Logisth PRIVATE LogisthFonts)
target_compile_definitions(Logisth PUBLIC JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JUCE_VST3_CAN_REPLACE_VST2=0)
target_link_libraries(Logisth PRIVATE juce::juce_audio_utils juce::juce_dsp PUBLIC juce::juce_recommended_config_flags)
FetchContent_Declare(clap_juce_extensions GIT_REPOSITORY https://github.com/free-audio/clap-juce-extensions.git GIT_TAG 6bde108329ff9fc24404b79b8b397261a75cf6a8)
FetchContent_MakeAvailable(clap_juce_extensions)
clap_juce_extensions_plugin(TARGET Logisth CLAP_ID "com.wavelogik.logisth" CLAP_FEATURES instrument synthesizer stereo)
if(APPLE)
  set_target_properties(Logisth_CLAP PROPERTIES
    MACOSX_BUNDLE_BUNDLE_VERSION "${logisth_apple_build}"
    MACOSX_BUNDLE_SHORT_VERSION_STRING "${logisth_marketing}"
    MACOSX_BUNDLE_INFO_STRING "logisth ${PROJECT_VERSION}")
endif()
if(BUILD_TESTING)
  add_executable(processor_tests tests/ProcessorTests.cpp)
  target_include_directories(processor_tests PRIVATE Source)
  target_compile_definitions(processor_tests PRIVATE LOGISTH_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
  target_link_libraries(processor_tests PRIVATE Logisth juce::juce_audio_utils juce::juce_dsp)
  add_test(NAME processor COMMAND processor_tests)
endif()

if(BUILD_TESTING AND UNIX AND NOT APPLE)
  add_executable(clap_smoke tests/ClapSmoke.cpp)
  target_include_directories(clap_smoke PRIVATE Source  "${clap_juce_extensions_SOURCE_DIR}/clap-libs/clap/include")
  target_link_libraries(clap_smoke PRIVATE ${CMAKE_DL_LIBS})
  target_compile_definitions(clap_smoke PRIVATE LOGISTH_EXPECTED_VERSION="${PROJECT_VERSION}")
  add_test(NAME clap_binary COMMAND clap_smoke $<TARGET_FILE:Logisth_CLAP>)
endif()

if(BUILD_TESTING AND UNIX AND NOT APPLE)
  add_executable(vst3_smoke tests/Vst3Smoke.cpp)
  target_include_directories(vst3_smoke PRIVATE Source  "${juce_SOURCE_DIR}/modules/juce_audio_processors/format_types/VST3_SDK")
  target_link_libraries(vst3_smoke PRIVATE ${CMAKE_DL_LIBS})
  add_test(NAME vst3_binary COMMAND vst3_smoke $<TARGET_FILE:Logisth_VST3>)
endif()
