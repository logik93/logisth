# logisth 0.9.3 Kick benchmark

Synthetic clipped kick with a 52 Hz tail and a short pitched/noisy attack.
Compare kick-reference.wav with Kick mode at -12, -7, 0, +7 and +12 semitones.
All variants have Time Factor 1, neutral Width and 25 ms protected attack.
The protected segment is unchanged in the floating-point processing comparison;
measurements.csv reports maximum error and output peak. No reverb or limiter.
Use these repeatable fixtures for comparison, then audition your own kick samples.
This benchmark does not reproduce a proprietary Nimble Kick algorithm.
