# logisth factory collection

48 authored patches in eight categories. Embedded factory material only; no external samples.
Every patch includes a description and four neutral-at-zero performance macros.
Measurements: 48 kHz, full velocity, three-second chord/mono audition, default and maximum macros.
The twelve-second demo plays the first patch from each category.
