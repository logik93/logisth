<?php

declare(strict_types=1);

require __DIR__ . '/release.php';

use function Wavelogik\fetchRelease;
use function Wavelogik\latestRelease;
use const Wavelogik\RELEASES_URL;

$cacheDirectory = getenv('WAVELOGIK_CACHE_DIR') ?: sys_get_temp_dir() . '/wavelogik-' . hash('sha256', __DIR__);
$release = latestRelease($cacheDirectory, fetchRelease(...));
$releaseUrl = $release['url'] ?? RELEASES_URL . '/latest';

function escapeHtml(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>logisth | Polyphonic synthesizer by wavelogik</title>
    <meta
      name="description"
      content="logisth is an open-source polyphonic synthesizer with six oscillators, four sound engines, modulation and effects. Download VST3, CLAP or the standalone app."
    />
    <link rel="icon" href="assets/icon.svg" />
    <link rel="stylesheet" href="site.css" />
  </head>
  <body>
    <a class="skip" href="#main">Skip to content</a>
    <header class="top">
      <div class="wrap nav">
        <a class="brand" href="./" aria-label="wavelogik home"
          ><img src="assets/logisth.svg" alt="" />wavelogik</a
        >
        <nav aria-label="Main navigation">
          <a href="#instrument">Instrument</a><a href="#signal">Signal path</a
          ><a href="#docs">Documentation</a>
        </nav>
        <a class="get-small" href="#download"
          >Download <span aria-hidden="true" class="arrow up-right"></span></a
        >
      </div>
    </header>
    <main id="main">
      <section class="hero">
        <div class="wrap hero-inner">
          <div class="hero-art" aria-hidden="true">
            <img src="assets/spectrum.webp" alt="" fetchpriority="high" />
            <div class="spectrum-orbit"></div>
            <div class="spectrum-meter">
              <?php foreach ([18, 26, 38, 55, 71, 48, 63, 88, 72, 51, 77, 94, 83, 66, 43, 58, 40, 31, 20] as $i => $level): ?>
                <i style="--level: <?= $level ?>%; --beat: <?= $i * -97 ?>ms"></i>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="hero-copy">
            <div class="overline"><i></i> POLYPHONIC SYNTHESIZER</div>
            <h1>logisth</h1>
            <p>
              Combine classic synthesis, wavetables, sampling and granular
              synthesis in one instrument.
            </p>
            <div class="actions">
              <a class="button primary" href="#download"
                ><span aria-hidden="true" class="arrow down"></span> Download logisth</a
              ><a class="button ghost" href="#instrument"
                >Explore the instrument <span aria-hidden="true" class="arrow down-right"></span></a
              >
            </div>
            <div class="formats">VST3 <b>·</b> CLAP <b>·</b> STANDALONE</div>
          </div>
        </div>
      </section>
      <div class="spec-strip">
        <dl class="wrap specs">
          <div>
            <dt>Oscillators</dt>
            <dd>6</dd>
          </div>
          <div>
            <dt>Parts</dt>
            <dd>3 <small>A / B / C</small></dd>
          </div>
          <div>
            <dt>Polyphony</dt>
            <dd>32 <small>voices</small></dd>
          </div>
          <div>
            <dt>Unison detune</dt>
            <dd>400 <small>cents</small></dd>
          </div>
        </dl>
      </div>
      <section class="section wrap" id="instrument">
        <div class="section-head">
          <div>
            <p class="eyebrow">OSCILLATOR MODES</p>
            <h2>Choose your engine</h2>
          </div>
          <p>
            Choose a mode independently for each of the six oscillators and
            combine different sound sources within a single part.
          </p>
        </div>
        <div class="engine-tabs" aria-label="Oscillator engines">
          <a href="#classic" data-engine="classic">Classic</a
          ><a href="#wavetable" data-engine="wavetable">Wavetable</a
          ><a href="#sampler" data-engine="sampler">Sampler</a
          ><a href="#granular" data-engine="granular">Granular</a>
        </div>
        <div class="engine-list">
          <article class="engine" id="classic">
            <div class="shot">
              <a
                href="assets/classic.webp"
                aria-label="Enlarge the Classic mode screenshot"
                ><img
                  src="assets/classic.webp"
                  loading="lazy"
                  width="1240"
                  height="860"
                  alt="logisth interface showing Classic oscillators and unison controls"
              /></a>
            </div>
            <div class="engine-note">
              <p class="eyebrow">CLASSIC SYNTHESIS</p>
              <h3>Classic</h3>
              <p>
                Start with a single waveform and add unison voices. Adjust their
                detune, blend and stereo width.
              </p>
              <dl>
                <div>
                  <dt>Unison</dt>
                  <dd>Up to 8 voices</dd>
                </div>
                <div>
                  <dt>Detune</dt>
                  <dd>0–400 cents</dd>
                </div>
                <div>
                  <dt>Modulation</dt>
                  <dd>FM / AM / PWM</dd>
                </div>
              </dl>
            </div>
          </article>
          <article class="engine" id="wavetable">
            <div class="shot">
              <a
                href="assets/wavetable.webp"
                aria-label="Enlarge the Wavetable mode screenshot"
                ><img
                  src="assets/wavetable.webp"
                  loading="lazy"
                  width="1240"
                  height="860"
                  alt="Wavetable oscillator with a preview of its waveform frames"
              /></a>
            </div>
            <div class="engine-note">
              <p class="eyebrow">WAVETABLE SYNTHESIS</p>
              <h3>Wavetable</h3>
              <p>
                WT POS selects a single-cycle frame from the wavetable. Use an
                LFO to sweep the position of one oscillator or move a whole
                group in sync.
              </p>
              <dl>
                <div>
                  <dt>Position</dt>
                  <dd>WT POS</dd>
                </div>
                <div>
                  <dt>LFO targets</dt>
                  <dd>A1–C2 or groups</dd>
                </div>
              </dl>
            </div>
          </article>
          <article class="engine" id="sampler">
            <div class="shot">
              <a href="assets/sampler.webp" aria-label="Enlarge the Sampler mode screenshot"
                ><img
                  src="assets/sampler.webp"
                  loading="lazy"
                  width="1240"
                  height="860"
                  alt="Stereo sampler waveform with START and END markers"
              /></a>
            </div>
            <div class="engine-note">
              <p class="eyebrow">SAMPLE PLAYBACK</p>
              <h3>Sampler</h3>
              <p>
                Drop a sample onto the waveform display, select a region and
                automate START and END. Loop Tail plays the attack once and
                repeats the tail.
              </p>
              <dl>
                <div>
                  <dt>Import</dt>
                  <dd>WAV / AIFF / FLAC</dd>
                </div>
                <div>
                  <dt>Time stretching</dt>
                  <dd>Includes Signalsmith Stretch</dd>
                </div>
              </dl>
            </div>
          </article>
          <article class="engine" id="granular">
            <div class="shot">
              <a
                href="assets/granular.webp"
                aria-label="Enlarge the Granular mode screenshot"
                ><img
                  src="assets/granular.webp"
                  loading="lazy"
                  width="1240"
                  height="860"
                  alt="Granular oscillator with a waveform preview of the source sample"
              /></a>
            </div>
            <div class="engine-note">
              <p class="eyebrow">GRANULAR SYNTHESIS</p>
              <h3>Granular</h3>
              <p>
                Build textures from short grains of a sample. Adjust their
                length, spread and playback position while watching the active
                grains on the waveform.
              </p>
              <dl>
                <div>
                  <dt>Models</dt>
                  <dd>Cloud / Granulizer</dd>
                </div>
                <div>
                  <dt>Display</dt>
                  <dd>Playback position and active grains</dd>
                </div>
              </dl>
            </div>
          </article>
        </div>
      </section>
      <section class="signal" id="signal">
        <div class="wrap">
          <p class="eyebrow">SOUND DESIGN</p>
          <h2>Signal path</h2>
          <div class="signal-grid">
            <article>
              <span class="plot plot-mod" aria-hidden="true"></span>
              <h3>Modulation</h3>
              <p>
                Route envelopes, LFOs and controllers to parameters in parts A,
                B and C. Target individual oscillators or groups.
              </p>
            </article>
            <article>
              <span class="plot plot-band" aria-hidden="true"></span>
              <h3>Multiband distortion</h3>
              <p>
                Split the signal into up to four bands. Set the model, Drive
                and Mix for each band and compare the spectrum before and after
                processing.
              </p>
            </article>
            <article>
              <span class="plot plot-ir" aria-hidden="true"></span>
              <h3>Stereo reverb</h3>
              <p>
                Choose from five algorithmic reverbs or load your own impulse
                response. Save the stereo impulse response with the preset.
              </p>
            </article>
          </div>
        </div>
      </section>
      <section class="section wrap docs-download">
        <div id="docs">
          <p class="eyebrow">REFERENCE</p>
          <h2>Documentation</h2>
          <?php if ($release !== null): ?>
            <p class="manual-version">Version <?= escapeHtml($release['version']) ?> · English</p>
          <?php endif; ?>
          <?php foreach ([
              'user' => ['User manual', 'Controls, workflows and presets', 'docs/'],
              'technical' => ['Technical manual', 'Architecture, DSP and measurements', 'technical/'],
          ] as $key => [$title, $description, $local]): ?>
            <?php $manual = $release['manuals'][$key] ?? null; ?>
            <div class="manual-row">
              <a class="rowlink" href="<?= escapeHtml($manual['online'] ?? $local) ?>">
                <span><strong><?= escapeHtml($title) ?></strong><small><?= escapeHtml($description) ?></small></span>
              </a>
              <?php if ($manual !== null): ?>
                <div class="manual-formats">
                  <?php if ($manual['pdf'] !== null): ?>
                    <a href="<?= escapeHtml($manual['pdf']) ?>" aria-label="<?= escapeHtml($title) ?> PDF">PDF</a>
                  <?php endif; ?>
                  <a href="<?= escapeHtml($local) ?>" aria-label="<?= escapeHtml($title) ?> bundled edition">Bundled HTML</a>
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
        <div id="download">
          <?php if ($release !== null): ?>
            <p class="eyebrow">RELEASE <?= escapeHtml($release['version']) ?></p>
          <?php endif; ?>
          <h2>Download logisth</h2>
          <p>Each package includes VST3, CLAP and the standalone app.</p>
          <div class="downloads">
            <?php if ($release === null): ?>
              <a href="<?= escapeHtml($releaseUrl) ?>">View the latest release on GitHub</a>
            <?php else: ?>
              <?php foreach ($release['downloads'] as $platform => $package): ?>
                <?php if ($package['url'] !== null): ?>
                  <a href="<?= escapeHtml($package['url']) ?>">
                    <?= escapeHtml($platform) ?>
                    <small><?= escapeHtml($package['format']) ?></small>
                    <span aria-hidden="true" class="arrow down"></span>
                  </a>
                <?php else: ?>
                  <div class="download-unavailable">
                    <?= escapeHtml($platform) ?> <small>Package pending</small>
                  </div>
                <?php endif; ?>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </section>
    </main>
    <footer>
      <div class="wrap foot">
        <a class="brand" href="./"
          ><img src="assets/logisth.svg" alt="" />wavelogik</a
        ><span>wavelogik.pl</span
        ><a href="https://github.com/logik93/logisth">GitHub</a
        ><a href="<?= escapeHtml($releaseUrl) ?>"
          >Release notes</a
        >
      </div>
    </footer>
    <script src="site.js" defer></script>
  </body>
</html>
